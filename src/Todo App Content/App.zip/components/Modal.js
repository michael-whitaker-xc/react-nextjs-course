function Modal(props) {
  function confirmHandler() {
    props.onConfirm();
  }

  function cancelHandler() {
    props.onCancel();
  }

  return (
    <div className="modal">
      <p>Sure?</p>
      <button className="btn btn--alt" onClick={cancelHandler}>
        Cancel
      </button>
      <button className="btn" onClick={confirmHandler}>
        Confirm
      </button>
    </div>
  );
}

export default Modal;
